function transferStation (scope, $route, $routeParams, $location) {
  var standardCodes = scope.standardCodes;
  var id = $routeParams.id;
  var target = standardCodes.find(function (item) {
    return item.internalCode == id;
  })
  if (target && target.path) {
    window.location.replace(target.path);
  } else {
    target = standardCodes.find(function (item) {
      return !item.path;
    })
    $location.url(target.comments);
  }
}

